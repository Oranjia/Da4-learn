from django.apps import AppConfig


class ToolConfig(AppConfig):
    name = 'tool'
    verbose_name = '工具管理'
